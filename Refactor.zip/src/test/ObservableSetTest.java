package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ObservableSetTest {

	@Test
	public void testAdd() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIterator() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemove() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClear() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContains() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContainsAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsEmpty() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRetainAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToArray() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToArrayTArray() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testObservableSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetChanged() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClearChanged() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHasChanged() {
		fail("Not yet implemented"); // TODO
	}

}
