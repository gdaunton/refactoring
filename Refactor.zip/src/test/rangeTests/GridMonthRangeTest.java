package test.rangeTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class GridMonthRangeTest {

	@Test
	public void testGridMonthRange() {
		fail("Not yet implemented");
	}

	@Test
	public void testGridMonthRangeDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWeeks() {
		fail("Not yet implemented");
	}

	@Test
	public void testNextMonth() {
		fail("Not yet implemented");
	}

	@Test
	public void testPreviousMonth() {
		fail("Not yet implemented");
	}

}
