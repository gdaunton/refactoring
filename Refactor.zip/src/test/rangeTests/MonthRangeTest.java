package test.rangeTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class MonthRangeTest {

	@Test
	public void testMonthRange() {
		fail("Not yet implemented");
	}

	@Test
	public void testMonthRangeDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testNextMonth() {
		fail("Not yet implemented");
	}

	@Test
	public void testPreviousMonth() {
		fail("Not yet implemented");
	}

}
