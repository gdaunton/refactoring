package test.rangeTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class WeekRangeTest {

	@Test
	public void testWeekRange() {
		fail("Not yet implemented");
	}

	@Test
	public void testWeekRangeDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDays() {
		fail("Not yet implemented");
	}

	@Test
	public void testNextWeek() {
		fail("Not yet implemented");
	}

	@Test
	public void testPreviousWeek() {
		fail("Not yet implemented");
	}

}
