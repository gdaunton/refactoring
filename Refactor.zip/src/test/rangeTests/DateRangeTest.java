package test.rangeTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateRangeTest {

	@Test
	public void testEqualsObject() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDurationInDays() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDurationInMS() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetEndDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetStartDate() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
