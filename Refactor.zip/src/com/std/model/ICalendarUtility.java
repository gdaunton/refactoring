package com.std.model;

public interface ICalendarUtility {
	public void nextMonth(CalendarModel model);
	public void nextWeek(CalendarModel model);
	public void nextDay(CalendarModel model);
}
